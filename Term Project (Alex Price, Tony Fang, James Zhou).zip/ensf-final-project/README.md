# ensf-final-project

Group members:
Tony Fang - tony.fang1@ucalgary.ca
Alexander Price - alexander.price@ucalgary.ca
James Zhou - james.zhou1@ucalgary.ca

Start the server in "ServerController.java". Then the client can be started in "ClientController.java".

Bonus features implemented:
- Project demployment; server and client can be run on separate machines (shown in demo)
- Login/out feature with a list of users 
- Separate GUI for "admin" with the ability to create new courses (log in with username 'admin' and password 'admin')


User and password list:
Tim - 123
Jim - 1234
Joe - 12345
John - 321
Bill - 1111
Sam - 1122
Bob - bob
Karen - 123456789